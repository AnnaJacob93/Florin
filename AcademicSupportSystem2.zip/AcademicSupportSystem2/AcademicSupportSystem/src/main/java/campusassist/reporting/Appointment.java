package campusassist.reporting;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author florin
 */
// Appointment Class
class Appointment {
    private String date;
    private String studentName;
    private String type;
    private String time;

    public Appointment(String date, String studentName, String type, String time) {
        this.date = date;
        this.studentName = studentName;
        this.type = type;
        this.time = time;
    }

    public void displayInfo() {
        System.out.println(studentName + " has an appointment on " + date + " at " + time + " for " + type);
    }

    public String getType() { return type; }
    public String getTime() { return time; }

}