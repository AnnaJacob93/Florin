/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author florin
 */

package campusassist.reporting;

import java.util.*;

// FAQ Class
public class FAQ {
    private String question;
    private String answer;

    // Constructor
    public FAQ(String question, String answer) {
        this.question = question;
        this.answer = answer;
    }

    // Display a single FAQ
    public void displayFAQ() {
        System.out.println("Q: " + question);
        System.out.println("A: " + answer);
    }

    // Getters and Setters
    public void setQuestion(String question) {
        this.question = question;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    // Static list to hold all FAQs
    private static ArrayList<FAQ> faqs = new ArrayList<>();

    // Get the sample FAQs (initialize only once)
    public static ArrayList<FAQ> getSampleFAQs() {
        if (faqs.isEmpty()) {
            faqs.add(new FAQ("How do I book an Academic Support session?", "Go to the student portal and click 'Request Support'."));
            faqs.add(new FAQ("How long are sessions?", "Each session lasts 30 minutes."));
        }
        return faqs;
    }

    // Add a new FAQ
    public static void addFAQ(String question, String answer) {
        faqs.add(new FAQ(question, answer));
    }

    // Edit an existing FAQ by index
    public static void editFAQ(int index, String newQuestion, String newAnswer) {
        if (index >= 0 && index < faqs.size()) {
            faqs.get(index).setQuestion(newQuestion);
            faqs.get(index).setAnswer(newAnswer);
        } else {
            System.out.println("Invalid FAQ index.");
        }
    }

    // Remove an FAQ by index
    public static void removeFAQ(int index) {
        if (index >= 0 && index < faqs.size()) {
            faqs.remove(index);
        } else {
            System.out.println("Invalid FAQ index.");
        }
    }

    // Display all FAQs with numbering
    public static void displayAllFAQs() {
        for (int i = 0; i < faqs.size(); i++) {
            System.out.println("[" + i + "]");
            faqs.get(i).displayFAQ();
            System.out.println();
        }
    }
}
