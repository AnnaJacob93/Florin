/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author madal
 */
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class BookingSystem {

    public static void showReminders(Student student) {
        LocalDateTime now = LocalDateTime.now();

        for (Appointment appt : student.getAppointments()) {
            if (!appt.isCompleted()
                && appt.getDateTime().isAfter(now)
                && appt.getDateTime().isBefore(now.plusHours(24))) {
                System.out.println("🔔 Reminder: You have an Academic Support session at " + appt.getDateTime());
            }
        }
    }

    public static void requestAcademicSupport(Student student) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("\n📚 Booking Academic Support Session");

        System.out.print("Enter session date and time (dd-MM-yyyy HH:mm): ");
        String input = scanner.nextLine();

        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");
            LocalDateTime dateTime = LocalDateTime.parse(input, formatter);

            Appointment appt = new Appointment("Academic Support", dateTime);
            student.addAppointment(appt);

            System.out.println("✅ Session booked for " + dateTime);
        } catch (Exception e) {
            System.out.println("❌ Invalid date format. Try again.");
        }
    }

    public static void showAppointments(Student student) {
        LocalDateTime now = LocalDateTime.now();

        System.out.println("\n📅 Your Appointments:");
        for (Appointment appt : student.getAppointments()) {
            String status = appt.getDateTime().isBefore(now) ? "Past" : "Upcoming";
            System.out.println("- [" + status + "] " + appt.getCategory() + " at " + appt.getDateTime());
        }
    }

    public static void provideFeedback(Student student) {
        Scanner scanner = new Scanner(System.in);

        boolean found = false;
        for (Appointment appt : student.getAppointments()) {
            if (appt.isCompleted()) {
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("⚠️ No completed appointments to provide feedback for.");
            return;
        }

        System.out.println("\n📝 Provide Feedback:");
        for (int i = 0; i < student.getAppointments().size(); i++) {
            Appointment appt = student.getAppointments().get(i);
            if (appt.isCompleted()) {
                System.out.println((i + 1) + ". " + appt.getCategory() + " at " + appt.getDateTime());
            }
        }

        System.out.print("Enter the number of the appointment: ");
        int index = scanner.nextInt();
        scanner.nextLine(); // clear input

        if (index < 1 || index > student.getAppointments().size()) {
            System.out.println("❌ Invalid appointment number.");
            return;
        }

        Appointment selectedAppt = student.getAppointments().get(index - 1);
        if (!selectedAppt.isCompleted()) {
            System.out.println("⚠️ This appointment is not completed yet.");
            return;
        }

        System.out.print("Enter feedback comments: ");
        String comments = scanner.nextLine();
        System.out.print("Enter rating (1 to 5): ");
        int rating = scanner.nextInt();

        System.out.println("✅ Thank you! Your feedback has been recorded.");
    }

    public static void markAppointmentCompleted(Student student) {
        Scanner scanner = new Scanner(System.in);

        if (student.getAppointments().isEmpty()) {
            System.out.println("⚠️ No appointments to mark as completed.");
            return;
        }

        System.out.println("\n✅ Mark Appointment as Completed:");
        for (int i = 0; i < student.getAppointments().size(); i++) {
            Appointment appt = student.getAppointments().get(i);
            System.out.println((i + 1) + ". " + appt.getCategory() + " at " + appt.getDateTime());
        }

        System.out.print("Enter the number of the appointment to mark as completed: ");
        int index = scanner.nextInt();

        if (index < 1 || index > student.getAppointments().size()) {
            System.out.println("❌ Invalid appointment number.");
            return;
        }

        Appointment selectedAppt = student.getAppointments().get(index - 1);
        selectedAppt.markCompleted();

        System.out.println("✅ Appointment marked as completed.");
    }
}