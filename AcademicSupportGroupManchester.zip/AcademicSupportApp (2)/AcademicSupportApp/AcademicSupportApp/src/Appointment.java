/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author madal
 */
import java.time.LocalDateTime;

public class Appointment {
    private final String category;
    private final LocalDateTime dateTime;
    private boolean completed;

    public Appointment(String category, LocalDateTime dateTime) {
        this.category = category;
        this.dateTime = dateTime;
        this.completed = false;
    }

    public String getCategory() {
        return category;
    }

    public LocalDateTime getDateTime() {
        return dateTime;
    }

    public boolean isCompleted() {
        return completed;
    }

    public void markCompleted() {
        this.completed = true;
    }
}