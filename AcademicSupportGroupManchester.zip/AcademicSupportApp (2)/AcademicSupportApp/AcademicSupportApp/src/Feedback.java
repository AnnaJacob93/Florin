
import javax.annotation.processing.SupportedSourceVersion;
import javax.lang.model.SourceVersion;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author madal
 */
 public class Feedback {
     private String comments;
     private int rating;
     
     public Feedback(){
         this.comments = "";
         this.rating = 0;
         
     }
         public Feedback(String comments, int rating) {
         this.comments = comments;
         this.rating = rating;
     }
 
     public String getComments(){
         return comments;
     }
    
      public String getRating(){
          return comments;
      }
 }