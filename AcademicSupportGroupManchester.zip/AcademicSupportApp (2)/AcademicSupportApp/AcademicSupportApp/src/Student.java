/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author madal
 */

import java.util.ArrayList;

public class Student {
    private String name;
    private String studentId;
    private ArrayList<Appointment> appointments;

    // ✅ THIS IS THE CONSTRUCTOR YOU NEED
    public Student(String name, String studentId) {
        this.name = name;
        this.studentId = studentId;
        this.appointments = new ArrayList<>();
    }

    public void addAppointment(Appointment appt) {
        appointments.add(appt);
    }

    public ArrayList<Appointment> getAppointments() {
        return appointments;
    }

    public String getName() {
        return name;
    }
}