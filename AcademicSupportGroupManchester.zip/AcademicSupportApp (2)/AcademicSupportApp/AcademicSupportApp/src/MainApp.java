/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author madal
 */

    
import java.util.Scanner;
import java.time.LocalDateTime;
public class MainApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Student student = new Student("Alice", "S1001");

        System.out.println(" Welcome, " + student.getName());

        // Show reminders when logging in
        BookingSystem.showReminders(student);

        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. Book Academic Support Session");
            System.out.println("2. View Appointments");
            System.out.println("3. Provide Feedback");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");

            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    BookingSystem.requestAcademicSupport(student);
                    break;
                case "2":
                    BookingSystem.showAppointments(student);
                    break;
                case "3":
                    BookingSystem.provideFeedback(student);
                    break;
                case "4":
                    System.out.println("👋 Goodbye!");
                    System.exit(0);
                default:
                    System.out.println("❌ Invalid choice. Try again.");
            }
        }
    }
}
