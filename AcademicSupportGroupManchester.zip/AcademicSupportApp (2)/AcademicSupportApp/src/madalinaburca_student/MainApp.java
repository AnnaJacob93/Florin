package madalinaburca_student;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author madal
 */

import java.util.Scanner;

public class MainApp {

    public void start() {
        Scanner scanner = new Scanner(System.in);
        Student student = new Student("Alexandra", "S2025");

        System.out.println("🎓 Welcome, " + student.getName());

        // Show reminders when logging in
        student.showReminders();

        boolean running = true;

        while (running) {
            System.out.println("\nStudent Menu:");
            System.out.println("1. Book Academic Support Session");
            System.out.println("2. View Appointments");
            System.out.println("3. Provide Feedback");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");

            String choice = scanner.nextLine();

            switch (choice) {
                case "1": BookingSystem.requestAcademicSupport(student);
                case "2":  BookingSystem.showAppointments(student);
                case "3": BookingSystem.provideFeedback(student);
                case "4": {
                    System.out.println("Exiting Student section...");
                    running = false;
                }
                default: System.out.println("Invalid choice. Try again.");
            }
        }
    }
}
