package madalinaburca_student;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author madal
 */

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class Student {
    private final String name; //Student name 
    private final String studentId;  //StudentID
    private final ArrayList<Appointment> appointments;  //List of their support session

    // Constructor to set up the student
    public Student(String name, String studentId) {
        this.name = name;
        this.studentId = studentId;
        this.appointments = new ArrayList<>();
    }
public void showReminders() {
    boolean hasUpcoming = false;

    for (Appointment appt : appointments) {
        if (appt.isUpcomingSoon()) {
            //  Show greeting only if there's a reminder
            System.out.println("Hello " + name + "!");
            
            //Show reminder with formatted date and time
            System.out.println("Quick reminder – your " + appt.getCategory() + " session is scheduled for " +
                appt.getDateTime().toLocalDate().format(DateTimeFormatter.ofPattern("dd-MMM-yyyy")) +
                " at " +
                appt.getDateTime().toLocalTime().format(DateTimeFormatter.ofPattern("hh:mm a")));

            hasUpcoming = true;
            break; 
        }
    }

    
}

 
//Add a new appointment to the student's list
    public void addAppointment(Appointment appt) {
        appointments.add(appt);
    }
//get the list of all appointments
    public ArrayList<Appointment> getAppointments() {
        return appointments;
    }
// Get the student's name
    public String getName() {
        return name;
    }
    public String getStudentId(){
        return studentId;
    }

    void addFeedback(Feedback feedback) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}