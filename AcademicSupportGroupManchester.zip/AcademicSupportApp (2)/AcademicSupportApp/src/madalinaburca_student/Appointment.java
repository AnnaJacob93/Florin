package madalinaburca_student;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 *
 *
 * @author madal
 */
import java.time.LocalDateTime;

public class Appointment {
    private final String category;
    private final LocalDateTime dateTime;
    private boolean completed;
    
//Creates a new appointment with the given category and time
    public Appointment(String category, LocalDateTime dateTime) {
        this.category = category;
        this.dateTime = dateTime;
        this.completed = false;// appointment is not completed by default
    }
//Returns  the type of support( e.g Academic Support)
    public String getCategory() {
        return category;
    }
//Returns the scheduled date and time
    public LocalDateTime getDateTime() {
        return dateTime;
    }
//Returns true if the appointment is marked as completed
    public boolean isCompleted() {
        return completed;
    }
//Marks the appointment as completed ( e.g. after the feedback is given)
    public void markCompleted() {
        this.completed = true;
    }
      // Checks if the appointment is coming up in the next 24 hours
    public boolean isUpcomingSoon() {
        LocalDateTime now = LocalDateTime.now();
        long hoursUntil = java.time.Duration.between(now, dateTime).toHours();

        return !completed && hoursUntil >= 0 && hoursUntil <= 24;
    }

    // Returns a short summary for display in the console

    @Override
    public String toString() {
        String status = completed ? "Completed" : "Upcoming";
        return category + " on " + dateTime.toString() + " [" + status + "]";
    }
}