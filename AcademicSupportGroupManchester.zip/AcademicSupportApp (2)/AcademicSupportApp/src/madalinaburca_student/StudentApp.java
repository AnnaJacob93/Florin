/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package madalinaburca_student;

/**
 *
 * @author Administrator
 */

import java.util.Scanner;

public class StudentApp {

    private Student student;

    public StudentApp() {
        // Simulated student object (can later be passed from Login logic)
        this.student = new Student("Alexandra", "S2025");
    }

    public void start() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("🎓 Welcome, " + student.getName());
        student.showReminders();

        boolean running = true;

        while (running) {
            System.out.println("\n--- Student Menu ---");
            System.out.println("1. Book Academic Support Session");
            System.out.println("2. View Appointments");
            System.out.println("3. Provide Feedback");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");

            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    BookingSystem.requestAcademicSupport(student);
                    break;
                case "2":
                    BookingSystem.showAppointments(student);
                    break;
                case "3":
                    BookingSystem.provideFeedback(student);
                    break;
                case "4":
                    System.out.println("Goodbye!");
                    running = false;
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }
}
