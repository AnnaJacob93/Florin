package madalinaburca_student;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author madal
 */
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;


public class BookingSystem {

    // Shows upcoming sessions within the next 24 hours
    public static void showReminders(Student student) {
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");

        for (Appointment appt : student.getAppointments()) {
            if (!appt.isCompleted()
                    && appt.getDateTime().isAfter(now)
                    && appt.getDateTime().isBefore(now.plusHours(24))) {

                System.out.println("You have an upcoming Academic Support session at " +
                        appt.getDateTime().format(formatter));
            }
        }
    }

    // Lets a student book a new support session
    public static void requestAcademicSupport(Student student) {
        Scanner scanner = new Scanner(System.in);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");

        System.out.println("\nBooking an Academic Support Session");

        while (true) {
            System.out.print("Enter session date and time (e.g. 20-04-2025 14:00): ");
            String input = scanner.nextLine();

            try {
                LocalDateTime dateTime = LocalDateTime.parse(input, formatter);

                // Check for duplicate appointment
                boolean alreadyBooked = false;
                for (Appointment appt : student.getAppointments()) {
                    if (appt.getDateTime().equals(dateTime)) {
                        alreadyBooked = true;
                        break;
                    }
                }

                if (alreadyBooked) {
                    System.out.println("That time is already booked. Please choose another.");
                    continue;
                }

                Appointment appt = new Appointment("Academic Support", dateTime);
                student.addAppointment(appt);
                System.out.println("Session successfully booked for " + dateTime.format(formatter));
                break;

            } catch (Exception e) {
                System.out.println("Invalid date format. Please try again.");
            }
        }
    }

    // Displays all sessions (past and upcoming)
    public static void showAppointments(Student student) {
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");

        System.out.println("\nYour Appointments:");
        for (Appointment appt : student.getAppointments()) {
            String status = appt.getDateTime().isBefore(now) ? "Past" : "Upcoming";
            String formattedTime = appt.getDateTime().format(formatter);
            System.out.println("- " + appt.getCategory() + " at " + formattedTime + " [" + status + "]");
        }
    }

    // Allows feedback on completed sessions
    public static void provideFeedback(Student student) {
        Scanner scanner = new Scanner(System.in);
        boolean found = false;

        for (Appointment appt : student.getAppointments()) {
            if (appt.isCompleted()) {
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("You don't have any completed appointments to give feedback on.");
            return;
        }

        System.out.println("\nCompleted Appointments:");
        for (int i = 0; i < student.getAppointments().size(); i++) {
            Appointment appt = student.getAppointments().get(i);
            if (appt.isCompleted()) {
                System.out.println((i + 1) + ". " + appt.getCategory() + " at " +
                        appt.getDateTime().format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm")));
            }
        }

        System.out.print("Enter the number of the appointment: ");
        int index = scanner.nextInt();
        scanner.nextLine();

        if (index < 1 || index > student.getAppointments().size()) {
            System.out.println("Invalid appointment number.");
            return;
        }

        Appointment selectedAppt = student.getAppointments().get(index - 1);
        if (!selectedAppt.isCompleted()) {
            System.out.println("This appointment is not marked as completed yet.");
            return;
        }

        System.out.print("Enter your feedback: ");
        String comment = scanner.nextLine();
        System.out.print("Enter a rating (1 to 5): ");
        int rating = scanner.nextInt();

        Feedback feedback = new Feedback(comment, rating);        student.addFeedback(feedback);

        System.out.println("Thank you for your feedback.");
    }

    // Lets the student mark a session as completed
    public static void markAppointmentCompleted(Student student) {
        Scanner scanner = new Scanner(System.in);

        if (student.getAppointments().isEmpty()) {
            System.out.println("There are no appointments to mark as completed.");
            return;
        }

        System.out.println("\nAppointments:");
        for (int i = 0; i < student.getAppointments().size(); i++) {
            Appointment appt = student.getAppointments().get(i);
            System.out.println((i + 1) + ". " + appt.getCategory() + " at " +
                    appt.getDateTime().format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm")));
        }

        System.out.print("Enter the number of the appointment to mark as completed: ");
        int index = scanner.nextInt();

        if (index < 1 || index > student.getAppointments().size()) {
            System.out.println("Invalid appointment number.");
            return;
        }

        Appointment selectedAppt = student.getAppointments().get(index - 1);
        selectedAppt.markCompleted();

        System.out.println("Appointment marked as completed.");
    }
}