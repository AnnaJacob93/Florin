package madalinaburca_student;


import javax.annotation.processing.SupportedSourceVersion;
import javax.lang.model.SourceVersion;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author madal
 */
 public class Feedback {
     private String comments; //What student said
     private int rating; // rating from 1 to 5
     
     //Empty constructor , in case
     public Feedback(){
         this.comments = "";
         this.rating = 0;
         
     }
     //Constructor to create feedback with comment and rating
         public Feedback(String comments, int rating) {
         this.comments = comments;
         this.rating = rating;
     }
 //Returns the writen feedback
     public String getComments(){
         return comments;
     }
    //Returns the rating(1-5)
      public int getRating(){
          return rating;
      }
     // Nicely format the feedback for printing
     @Override
        public String toString() {
        return "Rating: " + rating + "/5 - " + comments;
    }
      
 }