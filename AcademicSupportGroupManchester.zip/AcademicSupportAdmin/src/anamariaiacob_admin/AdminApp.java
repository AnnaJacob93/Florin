/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package anamariaiacob_admin;

/**
 *
 * @author Anamaria Iacob
 */

import java.util.Scanner;

public class AdminApp {

    private Admin admin = new Admin(1, "Admin User", "admin@email.com", "adminPassword");

    public void start() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("🔐 Admin Logged In (Integrated View)");

        boolean continueLoop = true;

        while (continueLoop) {
            System.out.println("\n--- Admin Menu ---");
            System.out.println("1. View Appointments");
            System.out.println("2. Manage Appointments");
            System.out.println("3. View Feedback");
            System.out.println("4. View Users");
            System.out.println("5. Update User");
            System.out.println("6. Delete User");
            System.out.println("7. Add New User");
            System.out.println("8. Exit");

            int choice = scanner.nextInt();
            scanner.nextLine(); // clean up input

            switch (choice) {
                case 1:
                    admin.viewAppointments();
                    break;
                case 2:
                    manageAppointmentsMenu(scanner);
                    break;
                case 3:
                    admin.viewFeedback();
                    break;
                case 4:
                    admin.viewUsers();
                    break;
                case 5:
                    updateUserMenu(scanner);
                    break;
                case 6:
                    deleteUserMenu(scanner);
                    break;
                case 7:
                    addNewUser(scanner);
                    break;
                case 8:
                    System.out.println("Exiting Admin section...");
                    continueLoop = false;
                    break;
                default:
                    System.out.println("Invalid option.");
            }
        }
    }

    private void addNewUser(Scanner scanner) {
        System.out.println("Enter new user details:");
        System.out.print("Name: ");
        String name = scanner.nextLine();
        System.out.print("Email: ");
        String email = scanner.nextLine();
        System.out.print("Password: ");
        String password = scanner.nextLine();
        System.out.print("Role (admin/student): ");
        String role = scanner.nextLine();

        User newUser = new User(admin.getUsers().size() + 1, name, role, email, password);
        admin.getUsers().add(newUser);
        System.out.println("User added!");
    }

    private void updateUserMenu(Scanner scanner) {
        admin.viewUsers();
        System.out.print("Email of user to update: ");
        String email = scanner.nextLine();
        System.out.print("New name: ");
        String newName = scanner.nextLine();
        admin.updateUser(email, newName);
    }

    private void deleteUserMenu(Scanner scanner) {
        admin.viewUsers();
        System.out.print("Email of user to delete: ");
        String email = scanner.nextLine();
        admin.deleteUser(email);
    }

    private void manageAppointmentsMenu(Scanner scanner) {
        boolean back = false;
        while (!back) {
            System.out.println("\nAppointment Management:");
            System.out.println("1. Approve");
            System.out.println("2. Reschedule");
            System.out.println("3. Cancel");
            System.out.println("4. Back");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Student name to approve: ");
                    String nameApprove = scanner.nextLine();
                    Appointment toApprove = findAppointmentByStudentName(nameApprove);
                    if (toApprove != null) {
                        admin.approveAppointment(toApprove);
                    } else {
                        System.out.println("Appointment not found.");
                    }
                    break;

                case 2:
                    System.out.print("Student name to reschedule: ");
                    String nameReschedule = scanner.nextLine();
                    Appointment toReschedule = findAppointmentByStudentName(nameReschedule);
                    if (toReschedule != null) {
                        System.out.print("New date/time: ");
                        String newDate = scanner.nextLine();
                        admin.rescheduleAppointment(toReschedule, newDate);
                    } else {
                        System.out.println("Appointment not found.");
                    }
                    break;

                case 3:
                    System.out.print("Student name to cancel: ");
                    String nameCancel = scanner.nextLine();
                    Appointment toCancel = findAppointmentByStudentName(nameCancel);
                    if (toCancel != null) {
                        admin.cancelAppointment(toCancel);
                    } else {
                        System.out.println("Appointment not found.");
                    }
                    break;

                case 4:
                    back = true;
                    break;

                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    private Appointment findAppointmentByStudentName(String studentName) {
        for (Appointment appointment : admin.getAppointments()) {
            if (appointment.getStudentName().equalsIgnoreCase(studentName)) {
                return appointment;
            }
        }
        return null;
    }
}
