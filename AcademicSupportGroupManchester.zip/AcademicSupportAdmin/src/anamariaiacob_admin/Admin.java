package anamariaiacob_admin;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

/**
 * This class represents an Admin user who can manage appointments, view feedback, and update user accounts.
 * @author Anamaria Iacob
 */

import java.util.ArrayList;
import java.util.List;



public class Admin {

    // Admin details and the lists they manage
    private int id;
    private String name;
    private String email;
    private String password;
    private List<Appointment> appointments;
    private List<Feedback> feedbacks;
    private List<User> users;

    // Admin constructor – creates a new admin with some data test
    public Admin(int id, String name, String email, String password) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.password = password;

        this.appointments = new ArrayList<>();
        this.feedbacks = new ArrayList<>();
        this.users = new ArrayList<>();

        // Sample data
        users.add(new User(1, "User One", "student", "user1@example.com", "password123"));
        users.add(new User(2, "User Two", "student", "user2@example.com", "password456"));

        appointments.add(new Appointment(1, "John Doe", "Academic Support", "2025-03-30 10:00"));
        appointments.add(new Appointment(2, "Jane Smith", "Mental Health", "2025-03-30 12:00"));

        feedbacks.add(new Feedback("John Doe", "Very helpful session!"));
        feedbacks.add(new Feedback("Jane Smith", "The session was good but could be longer."));
    }

    // Checks login credentials
    public boolean authenticate(String email, String password) {
        return this.email.equals(email) && this.password.equals(password);
    }

    public List<User> getUsers() {
        return users;
    }

    public String getName() {
        return name;
    }

    // View all appointments
    public void viewAppointments() {
        if (appointments.isEmpty()) {
            System.out.println("No appointments available.");
        } else {
            System.out.println("Appointments:");
            System.out.printf("%-30s%-30s%-30s%-30s\n", "Student", "Category", "DateTime", "Status");
            System.out.println("-------------------------------------------------------------");

            for (Appointment appointment : appointments) {
                System.out.printf("%-30s%-30s%-30s%-30s\n",
                        appointment.getStudentName(),
                        appointment.getCategory(),
                        appointment.getDateTime(),
                        appointment.getStatus());
            }
        }
    }

    public List<Appointment> getAppointments() {
        return appointments;
    }

    // View feedback
    public void viewFeedback() {
        if (feedbacks.isEmpty()) {
            System.out.println("No feedback available.");
        } else {
            System.out.println("Feedback:");
            System.out.printf("%-20s%-50s\n", "Student", "Feedback");
            System.out.println("-----------------------------------------");
            for (Feedback feedback : feedbacks) {
                System.out.printf("%-20s%-50s\n", feedback.getName(), feedback.getMessage());
            }
        }
    }

    // Appointment management
    public void approveAppointment(Appointment appt) {
        appt.setStatus("approved");
        System.out.println("Appointment approved: " + appt);
    }

    public void rescheduleAppointment(Appointment appt, String newDate) {
        appt.setDateTime(newDate);
        System.out.println("Appointment rescheduled to: " + newDate);
    }

    public void cancelAppointment(Appointment appt) {
        appt.setStatus("cancelled");
        System.out.println("Appointment cancelled: " + appt);
    }

    // User management
    public void updateUser(String email, String newName) {
        for (User user : users) {
            if (user.getEmail().equals(email)) {
                user.setName(newName);
                System.out.println("User updated!");
                return;
            }
        }
        System.out.println("User not found.");
    }

    public void viewUsers() {
        if (users.isEmpty()) {
            System.out.println("No users available.");
        } else {
            System.out.println("Users:");
            System.out.printf("%-20s%-30s%-30s\n", "Name", "Email", "Role");
            System.out.println("----------------------------------------------------------");

            for (User user : users) {
                System.out.printf("%-20s%-30s%-30s\n",
                        user.getName(),
                        user.getEmail(),
                        user.getRole());
            }
        }
    }

    public void deleteUser(String email) {
        users.removeIf(user -> user.getEmail().equals(email));
        System.out.println("User deleted.");
    }

    // ✅ NEW METHODS FOR SEARCHING BY STUDENT NAME

    public void approveByStudentName(String studentName) {
        for (Appointment a : appointments) {
            if (a.getStudentName().equalsIgnoreCase(studentName)) {
                approveAppointment(a);
                return;
            }
        }
        System.out.println("Appointment not found.");
    }

    public void rescheduleByStudentName(String studentName, String newDate) {
        for (Appointment a : appointments) {
            if (a.getStudentName().equalsIgnoreCase(studentName)) {
                rescheduleAppointment(a, newDate);
                return;
            }
        }
        System.out.println("Appointment not found.");
    }

    public void cancelByStudentName(String studentName) {
        for (Appointment a : appointments) {
            if (a.getStudentName().equalsIgnoreCase(studentName)) {
                cancelAppointment(a);
                return;
            }
        }
        System.out.println("Appointment not found.");
    }
}
