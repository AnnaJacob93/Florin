package anamariaiacob_admin;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

/**
 * This class represents feedback from a student after a support session.
 * It stores the student's name and the message they wrote.
 * 
 * @author Anamaria Iacob
 */

public class Feedback {
    // These are the feedback details
    private String name;    // The name of the student who gave the feedback
    private String message; // The message the student wrote

    // Constructor – when we create a Feedback object, we give it a name and message
    public Feedback(String name, String message) {
        this.name = name;        // Save the student's name
        this.message = message; // Save the feedback message
    }

    // Getters and setters – we use them to read or update the feedback

    public String getName() {
        return name; // Gives us the student's name
    }

    public void setName(String name) {
        this.name = name; // Lets us change the student's name
    }

    public String getMessage() {
        return message; // Gives us the feedback message
    }

    public void setMessage(String message) {
        this.message = message; // Lets us update the feedback message
    }

    // This makes it easy to print the feedback in a readable format
    @Override
    public String toString() {
        return "Feedback from " + name + ": " + message;
    }
}