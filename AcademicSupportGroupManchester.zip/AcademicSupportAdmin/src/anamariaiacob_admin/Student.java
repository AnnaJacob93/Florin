package anamariaiacob_admin;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

/**
 * This class represents a student user in the CampusAssist system.
 * It inherits all user details from the User class and sets the role to "student".
 * @author Anamaria Iacob
 */

public class Student extends User {
    
    // Constructor to create a new Student object
    // It uses the constructor of the parent class (User) to set the student details
    public Student(int id, String name, String email, String password) {
        super(id, name, "student", email, password);  // Call the parent class (User) constructor with student role
    }
}
