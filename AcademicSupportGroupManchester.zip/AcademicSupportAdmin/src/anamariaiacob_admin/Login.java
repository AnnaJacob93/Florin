package anamariaiacob_admin;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

/**
 * This class is the starting point of the CampusAssist console application.
 * It handles the login process and displays the appropriate menu based on the user's role.
 * Admins can manage appointments, users, and feedback through this menu.
 * Students will use their own menu in the future (not implemented yet).
 * @author Anamaria Iacob
 */

import anamariaiacob_admin.Appointment;
import anamariaiacob_admin.Admin;
import java.util.Scanner;

public class Login {

    // Create an Admin object with default login info and test data
    private static Admin admin = new Admin(1, "Admin User", "admin@email.com", "123admin");

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Welcome message
        System.out.println("Welcome to CampusAssist");

        // Ask the user to enter their login info
        System.out.print("Enter email: ");
        String email = scanner.nextLine();

        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        System.out.print("Enter role (admin/student): ");
        String role = scanner.nextLine();

        // Check what type of user is trying to log in
        if (role.equalsIgnoreCase("admin")) {
            // Check if the admin email and password are correct
            if (admin.authenticate(email, password)) {
                System.out.println("Admin logged in successfully!");
                adminMenu();  // Show the admin menu
            } else {
                System.out.println("Invalid email or password for admin.");
            }
        } else if (role.equalsIgnoreCase("student")) {
            System.out.println("Student logged in successfully!");
            studentMenu();  // Placeholder for student menu (not yet implemented)
        } else {
            System.out.println("Invalid role.");  // If user types something wrong
        }
    }

    // Admin menu: shows options for managing the system
    private static void adminMenu() {
        Scanner scanner = new Scanner(System.in);
        boolean continueLoop = true;

        while (continueLoop) {
            // Print menu options for the admin
            System.out.println("Admin Menu:");
            System.out.println("1. View Appointments");
            System.out.println("2. Manage Appointments");
            System.out.println("3. View Feedback");
            System.out.println("4. View Users");
            System.out.println("5. Update User");
            System.out.println("6. Delete User");
            System.out.println("7. Add New User");
            System.out.println("8. Logout");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Clean up the input

            // What happens based on the admin's choice
            switch (choice) {
                case 1:
                    admin.viewAppointments();  // Show all appointments
                    break;
                case 2:
                    manageAppointmentsMenu();  // Go to appointment management
                    break;
                case 3:
                    admin.viewFeedback();  // Show feedback
                    break;
                case 4:
                    admin.viewUsers();  // Show all users
                    break;
                case 5:
                    updateUserMenu();  // Change a user's name
                    break;
                case 6:
                    deleteUserMenu();  // Remove a user
                    break;
                case 7:
                    addNewUser();  // Add a new user to the system
                    break;
                case 8:
                    System.out.println("Logging out...");
                    continueLoop = false;  // Exit the loop and log out
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        }

        System.out.println("You have been logged out successfully!");
    }

    // Add a new user to the system
    private static void addNewUser() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter new user details:");

        System.out.print("Enter name: ");
        String name = scanner.nextLine();

        System.out.print("Enter email: ");
        String email = scanner.nextLine();

        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        System.out.print("Enter role (admin/student): ");
        String role = scanner.nextLine();

        // Create and add new user
        User newUser = new User(admin.getUsers().size() + 1, name, role, email, password);
        admin.getUsers().add(newUser);

        System.out.println("New user added successfully!");
    }

    // Menu for approving, rescheduling, or cancelling appointments
    private static void manageAppointmentsMenu() {
        Scanner scanner = new Scanner(System.in);
        boolean validChoice = false;

        while (!validChoice) {
            System.out.println("Manage Appointments:");
            System.out.println("1. Approve Appointment");
            System.out.println("2. Reschedule Appointment");
            System.out.println("3. Cancel Appointment");
            System.out.println("4. Go Back");

            int choice = scanner.nextInt();
            scanner.nextLine();  // Clear the input line

            switch (choice) {
                case 1:
                    // Find appointment by student name and approve it
                    System.out.print("Enter the student name of the appointment you want to approve: ");
                    String studentNameToApprove = scanner.nextLine();
                    for (Appointment appointment : admin.getAppointments()) {
                        if (appointment.getStudentName().equalsIgnoreCase(studentNameToApprove)) {
                            admin.approveAppointment(appointment);
                            validChoice = true;
                            break;
                        }
                    }
                    if (!validChoice) {
                        System.out.println("Appointment not found.");
                    }
                    break;

                case 2:
                    // Find appointment and reschedule it
                    System.out.print("Enter the student name of the appointment you want to reschedule: ");
                    String studentNameToReschedule = scanner.nextLine();
                    for (Appointment appointment : admin.getAppointments()) {
                        if (appointment.getStudentName().equalsIgnoreCase(studentNameToReschedule)) {
                            System.out.print("Enter the new date and time for the appointment: ");
                            String newDate = scanner.nextLine();
                            admin.rescheduleAppointment(appointment, newDate);
                            validChoice = true;
                            break;
                        }
                    }
                    if (!validChoice) {
                        System.out.println("Appointment not found.");
                    }
                    break;

                case 3:
                    // Cancel an appointment
                    System.out.print("Enter the student name of the appointment you want to cancel: ");
                    String studentNameToCancel = scanner.nextLine();
                    for (Appointment appointment : admin.getAppointments()) {
                        if (appointment.getStudentName().equalsIgnoreCase(studentNameToCancel)) {
                            admin.cancelAppointment(appointment);
                            validChoice = true;
                            break;
                        }
                    }
                    if (!validChoice) {
                        System.out.println("Appointment not found.");
                    }
                    break;

                case 4:
                    validChoice = true;  // Exit this menu
                    break;

                default:
                    System.out.println("Invalid choice, please try again.");
            }
        }
    }

    // Update user information (change their name)
    private static void updateUserMenu() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Select a user to update:");
        admin.viewUsers();  // Show users first

        System.out.print("Enter the email of the user you want to update: ");
        String email = scanner.nextLine();

        System.out.print("Enter the new name: ");
        String newName = scanner.nextLine();

        admin.updateUser(email, newName);
    }

    // Delete a user from the system
    private static void deleteUserMenu() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Select a user to delete:");
        admin.viewUsers();  // Show list of users

        System.out.print("Enter the email of the user you want to delete: ");
        String email = scanner.nextLine();

        admin.deleteUser(email);
    }

    // Placeholder for the student menu (future implementation)
    private static void studentMenu() {
        System.out.println("Student Menu:");
        // Features for students will be added later
    }
}

