package anamariaiacob_admin;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

/**
  *This class represents a student support appointment.
 *It stores details like student name, type of support, date and status.
 * 
 * @author Anamaria Iacob
 */

public class Appointment {
    // These are the appointment's details
    private int id;               // Unique ID number for the appointment
    private String studentName;   // Name of the student who booked the session
    private String category;      // Type of support (e.g., Mental Health, Academic Support)
    private String dateTime;      // When the appointment will happen
    private String status;        // Current status: pending, approved, or cancelled

    // When we create a new appointment, it starts as "pending"
    public Appointment(int id, String studentName, String category, String dateTime) {
        this.id = id;
        this.studentName = studentName;
        this.category = category;
        this.dateTime = dateTime;
        this.status = "pending";  // All appointments start as pending
    }

    // Getters and setters to read and change the appointment details

    public int getId() {
        return id;  // Gives us the appointment ID
    }

    public void setId(int id) {
        this.id = id;  // Lets us change the appointment ID
    }

    public String getStudentName() {
        return studentName;  // Shows which student the appointment is for
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;  // Lets us change the student name
    }

    public String getCategory() {
        return category;  // Tells us what kind of support the student asked for
    }

    public void setCategory(String category) {
        this.category = category;  // Lets us change the support category
    }

    public String getDateTime() {
        return dateTime;  // Tells us the appointment date and time
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;  // Lets us change the appointment date and time
    }

    public String getStatus() {
        return status;  // Tells us the current status (pending, approved, or cancelled)
    }

    public void setStatus(String status) {
        this.status = status;  // Lets us update the appointment's status
    }

    // This method shows the full appointment info as a single text line
    @Override
    public String toString() {
        return "Appointment{" +
                "id=" + id +
                ", studentName='" + studentName + '\'' +
                ", category='" + category + '\'' +
                ", dateTime='" + dateTime + '\'' +
                ", status='" + status + '\'' +
                '}';  // Easy way to print all the appointment info together
    }
}