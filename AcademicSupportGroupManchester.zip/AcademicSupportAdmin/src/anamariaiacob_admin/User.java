package anamariaiacob_admin;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

/**
 * This class represents a general user in the CampusAssist system.
 * A user can be either an "admin" or a "student".
 * It contains basic details like name, role, email, and password.
 * @author Anamaria Iacob
 */

public class User {

    // Basic information about the user
    protected int id;               // Unique ID number for the user
    protected String name;          // User's name
    protected String role;          // Role: "admin" or "student"
    protected String email;         // User's email
    protected String password;      // User's password

    // Constructor – when we create a user, we provide their info
    public User(int id, String name, String role, String email, String password) {
        this.id = id;             // Save user ID
        this.name = name;         // Save user name
        this.role = role;         // Save user role (admin or student)
        this.email = email;       // Save email
        this.password = password; // Save password
    }

    // Getters and setters – allow reading and changing the user's data

    public int getId() {
        return id;  // Get the user's ID
    }

    public void setId(int id) {
        this.id = id;  // Change the user's ID
    }

    public String getName() {
        return name;  // Get the user's name
    }

    public void setName(String name) {
        this.name = name;  // Change the user's name
    }

    public String getRole() {
        return role;  // Get the user's role (admin/student)
    }

    public void setRole(String role) {
        this.role = role;  // Change the user's role
    }

    public String getEmail() {
        return email;  // Get the user's email
    }

    public void setEmail(String email) {
        this.email = email;  // Change the user's email
    }

    public String getPassword() {
        return password;  // Get the user's password
    }

    public void setPassword(String password) {
        this.password = password;  // Change the user's password
    }

    // Check if login details are correct (email and password must match)
    public boolean authenticate(String email, String password) {
        return this.email.equals(email) && this.password.equals(password);  // Return true if both match
    }
}