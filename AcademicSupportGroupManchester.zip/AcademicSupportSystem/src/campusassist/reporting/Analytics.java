/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author florin
 */
package campusassist.reporting;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

// Analytics Class
public class Analytics {
    private ArrayList<Appointment> appointments;
    private ArrayList<Feedback> feedbacks;

    // Constructor
    public Analytics() {
        this.appointments = new ArrayList<>();
        this.feedbacks = new ArrayList<>();
    }

    // Add a new appointment
    public void addAppointment(Appointment appointment) {
        appointments.add(appointment);
    }

    // Add a new feedback
    public void addFeedback(Feedback feedback) {
        feedbacks.add(feedback);
    }

    // Analyze appointment trends
    public void analyzeTrends() {
        System.out.println("Total Appointments: " + appointments.size());

        Map<String, Integer> categoryCount = new HashMap<>();
        for (Appointment a : appointments) {
            categoryCount.put(a.getType(), categoryCount.getOrDefault(a.getType(), 0) + 1);
        }
        System.out.println("Most Requested Support Categories: " + categoryCount);
    }

    // Calculate and display average feedback rating
    public void averageRating() {
        if (feedbacks.isEmpty()) {
            System.out.println("No feedback available.");
            return;
        }
        int sum = 0;
        for (Feedback f : feedbacks) {
            sum += f.getRating();
        }
        System.out.println("Average Rating: " + (double) sum / feedbacks.size());
    }

    // Display peak appointment times
    public void peakHours() {
        Map<String, Integer> timeSlots = new HashMap<>();
        for (Appointment a : appointments) {
            timeSlots.put(a.getTime(), timeSlots.getOrDefault(a.getTime(), 0) + 1);
        }
        System.out.println("Peak Appointment Times: " + timeSlots);
    }

    // NEW: Analyze feedback positivity
    public void analyzeFeedbackPositivity() {
        int positiveCount = 0;
        int negativeCount = 0;

        for (Feedback f : feedbacks) {
            if (f.getRating() >= 4) {
                positiveCount++;
            } else if (f.getRating() <= 2) {
                negativeCount++;
            }
        }

        System.out.println("Positive Feedbacks (4-5 stars): " + positiveCount);
        System.out.println("Negative Feedbacks (1-2 stars): " + negativeCount);
    }

    // NEW: Display all feedback comments
    public void displayFeedbackComments() {
        if (feedbacks.isEmpty()) {
            System.out.println("No feedback comments available.");
            return;
        }

        System.out.println("Feedback Comments:");
        for (Feedback f : feedbacks) {
            if (f.getComment() != null && !f.getComment().isEmpty()) {
                System.out.println("- " + f.getComment());
            }
        }
    }
}
