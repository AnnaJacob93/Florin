/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author florin
 */
package campusassist.reporting;

public class AnalyticsApp {
    
    public void start() {
        System.out.println("\n📊 Academic Support FAQs:");
        for (FAQ faq : FAQ.getSampleFAQs()) {
            faq.displayFAQ();
            System.out.println();
        }

        Analytics analytics = new Analytics();
        Admin admin = new Admin(analytics);

        // Simulate Appointments
        analytics.addAppointment(new Appointment("April 2, 2025", "John Doe", "Academic Support", "2 PM"));
        analytics.addAppointment(new Appointment("April 5, 2025", "Jane Smith", "Academic Support", "4 PM"));

        // Simulate Feedback
        analytics.addFeedback(new Feedback(5, "Great session!"));
        analytics.addFeedback(new Feedback(3, "It was okay."));
        analytics.addFeedback(new Feedback(1, "Not helpful."));

        // Generate Admin Report
        admin.generateReport();

        // Show feedback positivity stats
        analytics.analyzeFeedbackPositivity();

        // Show feedback comments
        analytics.displayFeedbackComments();
    }
}

