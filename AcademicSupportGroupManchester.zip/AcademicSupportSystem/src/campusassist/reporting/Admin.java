package campusassist.reporting;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author florin
 */
// Admin Class
class Admin {
    private Analytics analytics;

    public Admin(Analytics analytics) {
        this.analytics = analytics;
    }

    public void generateReport() {
        System.out.println("\n===== ADMIN REPORT =====");
        analytics.analyzeTrends();
        analytics.averageRating();
        analytics.peakHours();
    }
}