package campusassistconsole;

import anamariaiacob_admin.AdminApp;
import madalinaburca_student.StudentApp;
import campusassist.reporting.AnalyticsApp;
import java.util.Scanner;

/**
 * CampusAssistConsole - Console Application
 *
 * This application simulates an academic support system for students and administrators.
 *
 * Main functionalities:
 * - Login with email and password for Admin and Student
 * - Role-based personalized menus
 * - Appointment and user management (Admin)
 * - Academic session booking and feedback (Student)
 * - Analytics and FAQ viewing
 * - Logout and re-login without restarting the application

 * 
 * 
 * @author Anamaria Iacob, Madalina Burca, Florentin Gherghe
 */


public class CampusAssistConsole {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("\n🎓 Welcome to CampusAssist Console!");

        boolean mainRunning = true;

        while (mainRunning) {
            String role = "";
            boolean authenticated = false;
            int attempts = 0;

            // Select role
            while (!role.equalsIgnoreCase("admin") && !role.equalsIgnoreCase("student") && !role.equalsIgnoreCase("exit")) {
                System.out.print("\nAre you an Admin or a Student? (type 'admin', 'student', or 'exit' to quit): ");
                role = scanner.nextLine().trim().toLowerCase();

                if (role.equals("exit")) {
                    System.out.println("👋 Thank you for using CampusAssist Console. Goodbye!");
                    mainRunning = false;
                    break;
                }

                if (!role.equals("admin") && !role.equals("student")) {
                    System.out.println("❗ Invalid role. Please type 'admin', 'student', or 'exit'.");
                }
            }

            if (!mainRunning) {
                break;
            }

            // Login attempts
            while (!authenticated && attempts < 3) {
                System.out.print("\nEnter email: ");
                String email = scanner.nextLine();
                System.out.print("Enter password: ");
                String password = scanner.nextLine();

                if (role.equals("admin")) {
                    if (email.equals("admin@email.com") && password.equals("123admin")) {
                        authenticated = true;
                    } else {
                        System.out.println("❗ Invalid Admin credentials. Try again.");
                        attempts++;
                    }
                } else if (role.equals("student")) {
                    if (email.equals("student@email.com") && password.equals("123student")) {
                        authenticated = true;
                    } else {
                        System.out.println("❗ Invalid Student credentials. Try again.");
                        attempts++;
                    }
                }
            }

            // After 3 failed attempts
            if (!authenticated) {
                System.out.println("\n🔒 Too many failed login attempts. Returning to role selection...");
                continue; 
            }

            // Login successful
            System.out.println("\n✅ Login successful! Welcome " + role + "!");

            // User session
            boolean sessionRunning = true;
            while (sessionRunning) {
                System.out.println("\n=== Main Menu ===");
                if (role.equals("admin")) {
                    System.out.println("1. Admin Section");
                } else if (role.equals("student")) {
                    System.out.println("1. Student Section");
                }
                System.out.println("2. Analytics & FAQs");
                System.out.println("3. Logout");

                System.out.print("Enter your choice: ");
                String choice = scanner.nextLine();

                switch (choice) {
                    case "1":
                        if (role.equals("admin")) {
                            AdminApp adminApp = new AdminApp();
                            adminApp.start();
                        } else if (role.equals("student")) {
                            StudentApp studentApp = new StudentApp();
                            studentApp.start();
                        }
                        break;
                    case "2":
                        AnalyticsApp analyticsApp = new AnalyticsApp();
                        analyticsApp.start();
                        break;
                    case "3":
                        System.out.println("🔒 Logging out...");
                        sessionRunning = false;
                        break;
                    default:
                        System.out.println("❗ Invalid choice. Try again.");
                }
            }
        }

        scanner.close();
    }
}
